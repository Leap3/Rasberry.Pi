// START OF TUTORIAL

// Include the onoff Gpio library and declare led and button instances (what pin they are connected to, and their direction {output or input})
var Gpio = require("onoff").Gpio;
var led = new Gpio(4, "out");
var button = new Gpio(22, "in");

// Include the lcd library and declare the lcd instance, either only LCD library or onoff Gpio library can be used at a time, this is a bug with the app, it should happen otherwise
// var LCD = require("lcd");
// var lcd = new LCD({rs: 25, e: 2, data: [], cols: 16, rows: 2});

// Block 1: Tutorial Phase 0, Turn LED on then turn LED off
/*
 
led.writeSync(1);
sleep(2000);
led.writeSync(0);

/*

// Block 2: Tutorial Phase 1, Blink LED

led.writeSync(1);
sleep(500);
led.writeSync(0);
sleep(500);
led.writeSync(1);
sleep(500);
led.writeSync(0);

*/

/*

// Block 3: Tuturial Phase 2.1, How a while loop works

while(condition)
{
    // do stuff here;
}

*/

/*

// Block 3: Tuturial Phase 2.2, Blink LED using while loop

var iterator = 0;

while(iterator < 5) // while(1) will result in an infinite loop (let them about how indexing works)
{
    led.writeSync(1);
    sleep(500);
    led.writeSync(0);
    sleep(500);

    iterator = iterator + 1; // iterator++;
}

*/

/*

// Block 4: Tutorial Phase 3.1, How a for loop works

for(init_clause; condition; iteration_expression){
    // do stuff here;
}

*/

/*

// Block 4: Tutorial Phase 3.2, Blink LED using for loop

for(var j = 1; j < 1500; j *= 5){
    led.writeSync(1);
    sleep(500);
    led.writeSync(0);
    sleep(500);

    console.log("j = " + j);
}

*/

/*

// Block 5: Tutorial Phase 4, How to do an infinite loop using a for loop

for(;;){
    led.writeSync(1);
    sleep(250);
    led.writeSync(0);
    sleep(250);
}

*/

/*

// Block 6: Tutorial Phase 5, How to do an infinite loop using a while loop

while(1){
    if(button.readSync() == 0){
        led.writeSync(1);
    }
    else{
        led.writeSync(0);
    }
}

*/

/*

// Block 7: Tutorial Phase 6, Using a button to turn LED on or off

for(;;){
    if(button.readSync() == 0){ //take note of the "="
        led.writeSync(1);
    }

    else{
        led.writeSync(0);
    }

}

*/

/* // Block 8: Tutorial Phase 7 (LCD). How to print onto the LCD

var name = "Hello Mr Adrian :)";

for(var i = 5; i > 0; i--){
    print(i);

    sleep(1000);
}

*/

/* 

print(name);

for(var i = 0; i < 6; i ++) {
    sleep(500);
    lcd.scrollDisplayLeft();
}

*/

/* // Challenging Exercise code goes on the line below, make sure to comment lines 149 to 154
print_withLeftAdjust(name);

LCD_DeInit();

*/

console.log("End of Tutorial :)");

function print_withLeftAdjust(char)
{
    print(char);

    for(var i = 0; i < (char.length - 16); i++){
        sleep(500);
        scrollDisplayLeft();
        sleep(500);
    }
}

function print(char)
{
    lcd.print(char);
}

function scrollDisplayLeft()
{
    lcd.scrollDisplayLeft();
}

// Below is how to do doxygen comments, highly recommend doing

/*
 *  @brief  De-initialise LCD
 *  @param  void
 *  @retval None
 */
function LCD_DeInit()
{
    lcd.clear(); 
    lcd.close();
}

